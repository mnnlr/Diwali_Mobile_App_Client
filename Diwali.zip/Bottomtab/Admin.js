import React from 'react';
import { View, StyleSheet } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import Girls from '../Admin/Girls';
import Mens from '../Admin/Mens';
import Others from '../Admin/Others';

const Tab = createBottomTabNavigator();

function Admin() {
  return (

      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === 'Girls') {
              iconName = focused ? 'female' : 'female-outline';
            } else if (route.name === 'Mens') {
              iconName = focused ? 'male' : 'male-outline';
            } else if (route.name === 'Others') {
              iconName = focused ? 'ellipse' : 'ellipse-outline';
            }

            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: 'tomato',
          tabBarInactiveTintColor: 'gray',
        })}
      >
        <Tab.Screen name="Girls" component={Girls} />
        <Tab.Screen name="Mens" component={Mens} />
        <Tab.Screen name="Others" component={Others} />
      </Tab.Navigator>
 
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  card: {
    marginVertical: 8,
  },
  input: {
    borderBottomWidth: 1,
    borderBottomColor: 'gray',
  },
});

export default Admin;
