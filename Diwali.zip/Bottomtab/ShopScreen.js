import React, { useState, useEffect } from 'react';
import { View, StyleSheet, Text, Image, ScrollView, TouchableOpacity, ActivityIndicator, Modal, Dimensions, Alert } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { MaterialIcons } from '@expo/vector-icons';
import { addToCart, addToWatch } from '../Redux/action';
import { defaultAxios } from '../CustomAxios/DefaultAxios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { height } = Dimensions.get('window');

function ShopScreen({ navigation }) {
  const dispatch = useDispatch();
  const cartData = useSelector((state) => state.add);
  const [selectedSection, setSelectedSection] = useState('Men');
  const [pajama, setPajama] = useState([]);
  const [sherwani, setSherwani] = useState([]);
  const [lengha, setLengha] = useState([]);
  const [saree, setSaree] = useState([]);
  const [ethnicSets, setEthnicSets] = useState([]);
  const [kurti, setKurti] = useState([]);
  const [other, setOther] = useState([]);
  const [userData, setUserData] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [boys, setBoys] = useState([]);
  const [girls, setGirls] = useState([]);

  const getUserData = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('token');
      if (jsonValue !== null) {
        setUserData(JSON.parse(jsonValue));
      }
    } catch (e) {
      console.log('Failed to fetch the data from storage', e);
    }
  };

  const fetchData = async () => {
    try {
      setLoading(true);
      const pajamaRes = await defaultAxios.get("/clothing", { params: { categoryName: ["Ethnic", "Men", "Clothing", "Pajama"] } });
      const sherwaniRes = await defaultAxios.get("/clothing", { params: { categoryName: ["Ethnic", "Men", "Clothing", "Sets", "Sherwani"] } });
      const sareeRes = await defaultAxios.get("/clothing", { params: { categoryName: ['Clothing', 'Ethnic', 'Women', 'Saree'] } });
      const kurtiRes = await defaultAxios.get("/clothing", { params: { categoryName: ['Clothing','Ethnic','Women',"Girl",'Kurta&Kurtis'] } });
      const ethnicSetsRes = await defaultAxios.get("/clothing", { params: { categoryName: ["Ethnic", "Men", "Clothing", "Sets", "Ethnic Sets"] } });
      const lenghaRes = await defaultAxios.get("/clothing", { params: { categoryName: ['Clothing','Ethnic','Women',"Girl",'Lehnga Choli'] } });

      setPajama(pajamaRes.data.Data);
      setSherwani(sherwaniRes.data.Data);
      setSaree(sareeRes.data.Data);
      setKurti(kurtiRes.data.Data);
      setEthnicSets(ethnicSetsRes.data.Data);
      setLengha(lenghaRes.data.Data);
    } catch (err) {
      console.log(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getUserData();
    fetchData();
  }, []);

  const handleAddToCart = async (item) => {
    if (!userData) {
      Alert.alert('Login Required', 'Please login to add items to cart.', [
        { text: 'OK', onPress: () => navigation.navigate('LoginScreen') }
      ]);
      return;
    }

    try {
      const response = await defaultAxios.put('/cart', {}, {
        params: { id: item._id },
        headers: {
          'Authorization': `Bearer ${userData.Data.token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.status === 200) {
        alert(response.data.message);
        dispatch(addToCart(item));
      } else {
        console.error('Unexpected status code:', response.status);
        alert(`An unexpected error occurred: ${response.status}`);
      }
    } catch (err) {
      console.error('Error:', err);
      Alert.alert('Error', 'An error occurred while adding to cart.');
    }
  };

  const handleAddToWatchlist = async (item) => {
    if (!userData) {
      Alert.alert('Login Required', 'Please login to add items to watchlist.', [
        { text: 'OK', onPress: () => navigation.navigate('LoginScreen') }
      ]);
      return;
    }

    try {
      const response = await defaultAxios.put('/wishlist', {}, {
        params: { id: item._id },
        headers: {
          'Authorization': `Bearer ${userData.Data.token}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.status === 200) {
        alert(response.data.message);
        dispatch(addToWatch(item));
      } else {
        console.error('Unexpected status code:', response.status);
        alert(`An unexpected error occurred: ${response.status}`);
      }
    } catch (err) {
      console.error('Error:', err);
      Alert.alert('Error', 'An error occurred while adding to watchlist.');
    }
  };

  const handleProductPress = (item) => {
    navigation.navigate('ProductDetails', { product: item });
  };

  const renderData = () => {
    let data = [];
    switch (selectedFilter) {
      case 'Pajama':
        data = pajama;
        break;
      case 'Sherwani':
        data = sherwani;
        break;
      case 'Lengha':
        data = lengha;
        break;
      case 'Saree':
        data = saree;
        break;
      case 'Kurti':
        data = kurti;
        break;
      case 'Ethnic Sets':
        data = ethnicSets;
        break;
      case 'Boys':
        data = boys;
        break;
      case 'Girls':
        data = girls;
        break;
      default:
        data = other.concat(pajama).concat(sherwani).concat(lengha).concat(saree).concat(kurti).concat(ethnicSets);
        break;
    }

    return (
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {data.map((item, index) => (
          <TouchableOpacity key={index} onPress={() => handleProductPress(item)}>
            <View style={styles.cardContainer}>
              <Image source={{ uri: item.images[0] }} style={styles.cardImage} />
              <View style={styles.cardTextContainer}>
                <Text style={styles.cardTitle}>{item.name}</Text>
                <Text style={styles.cardPrice}>Price: {item.price}</Text>
                <Text style={styles.cardPrice}>Quantity: {item.stockQuantity}</Text>
              </View>
              <View style={styles.cardButtonContainer}>
                <TouchableOpacity style={styles.button} onPress={() => handleAddToCart(item)}>
                  <MaterialIcons name="add-shopping-cart" size={24} color="white" />
                </TouchableOpacity>
                <TouchableOpacity style={styles.button} onPress={() => handleAddToWatchlist(item)}>
                  <MaterialIcons name="playlist-add" size={24} color="white" />
                </TouchableOpacity>
              </View>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    );
  };

  const handleFilterChange = (filter) => {
    setSelectedFilter(filter);
    setModalVisible(false);
  };

  const renderFilterOptions = () => (
    <View style={[styles.modalContent, { backgroundColor: 'white' }]}>
      <View style={styles.leftSection}>
        <ScrollView>
          <TouchableOpacity onPress={() => setSelectedSection('Men')} style={styles.sectionButton}>
            <Text style={[styles.sectionButtonText, selectedSection === 'Men' && styles.selectedSectionButtonText]}>Men</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setSelectedSection('Women')} style={styles.sectionButton}>
            <Text style={[styles.sectionButtonText, selectedSection === 'Women' && styles.selectedSectionButtonText]}>Women</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setSelectedSection('Crackers')} style={styles.sectionButton}>
            <Text style={[styles.sectionButtonText, selectedSection === 'Crackers' && styles.selectedSectionButtonText]}>Crackers</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setSelectedSection('Kids')} style={styles.sectionButton}>
            <Text style={[styles.sectionButtonText, selectedSection === 'Kids' && styles.selectedSectionButtonText]}>Kids</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
      <View style={styles.rightSection}>
        <ScrollView>
          {selectedSection === 'Men' && (
            <>
              <Text style={styles.modalTitle}>Men</Text>
              <TouchableOpacity onPress={() => handleFilterChange('Pajama')} style={styles.modalButton}>
                <Text>Pajama</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleFilterChange('Sherwani')} style={styles.modalButton}>
                <Text>Sherwani</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleFilterChange('Ethnic Sets')} style={styles.modalButton}>
                <Text>Ethnic Sets</Text>
              </TouchableOpacity>
            </>
          )}
          {selectedSection === 'Women' && (
            <>
              <Text style={styles.modalTitle}>Women</Text>
              <TouchableOpacity onPress={() => handleFilterChange('Saree')} style={styles.modalButton}>
                <Text>Saree</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleFilterChange('Lengha')} style={styles.modalButton}>
                <Text>Lengha</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleFilterChange('Kurti')} style={styles.modalButton}>
                <Text>Kurti</Text>
              </TouchableOpacity>
            </>
          )}
          {selectedSection === 'Crackers' && (
            <>
              <Text style={styles.modalTitle}>Crackers</Text>
              <TouchableOpacity onPress={() => handleFilterChange('Bomb')} style={styles.modalButton}>
                <Text>Bomb</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleFilterChange('Fuljari')} style={styles.modalButton}>
                <Text>Fuljari</Text>
              </TouchableOpacity>
            </>
          )}
          {selectedSection === 'Kids' && (
            <>
              <Text style={styles.modalTitle}>Kids</Text>
              <TouchableOpacity onPress={() => handleFilterChange('Boys')} style={styles.modalButton}>
                <Text>Boys</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleFilterChange('Girls')} style={styles.modalButton}>
                <Text>Girls</Text>
              </TouchableOpacity>
            </>
          )}
        </ScrollView>
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="tomato" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.leftSide}>
        <TouchableOpacity style={styles.filterButton} onPress={() => setModalVisible(true)}>
          <Text style={styles.filterButtonText}>Filter</Text>
        </TouchableOpacity>
      </View>
      
      {renderData()}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          {renderFilterOptions()}
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 4,
    backgroundColor: '#f9f9f9',
  },
  filterButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    height: 40,
    borderColor: 'gray',
    borderRadius: 20,
    marginHorizontal: 5,
    backgroundColor: 'tomato',
    justifyContent: 'center',
    alignItems: 'flex-start',
    alignSelf: 'flex-start',
    marginVertical: 10,
  },
  filterButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  cardContainer: {
    borderWidth: 1,
    borderColor: 'lightgray',
    borderRadius: 10,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    width: '100%',
    justifyContent: 'space-between',
    padding: 10,
    backgroundColor: 'white',
  },
  cardImage: {
    width: 120,
    height: 140,
    borderRadius: 10,
  },
  cardTextContainer: {
    flex: 1,
    marginLeft: 10,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  cardPrice: {
    fontSize: 14,
    marginBottom: 5,
  },
  cardButtonContainer: {
    flexDirection: 'column',
    marginBottom: 6,
  },
  scrollContainer: {
    padding: 10,
  },
  button: {
    backgroundColor: 'tomato',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 5,
    marginHorizontal: 5,
    marginBottom: 10,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    flexDirection: 'row',
    flex: 1,
  },
  leftSection: {
    width: '30%',
    borderRightWidth: 1,
    borderRightColor: '#ccc',
    paddingVertical: 8,
  },
  sectionButton: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#f0f0f0',
    marginBottom: 1,
  },
  sectionButtonText: {
    fontSize: 16,
    color: '#333',
  },
  selectedSectionButtonText: {
    fontWeight: 'bold',
  },
  rightSection: {
    width: '70%',
    padding: 16,
    borderRightWidth: 1,
    borderRightColor: '#ccc',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  modalButton: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
});

export default ShopScreen;
